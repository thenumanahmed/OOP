#pragma once
#include<iostream>
#include<string>

using namespace std;
class GPA {
	float eng,
		urdu,
		isl,
		math,
		pst,
		phy;

	int engCreditHour,
		urduCreditHour,
		islCreditHour,
		mathCreditHour,
		pstCreditHour,
		phyCreditHour;

public:
	//Constructor
	GPA();

	//Mutator
	void setEngMarksAndCH(float, int);
	void setUrduMarksAndCH(float, int);
	void setIslMarksAndCH(float, int);
	void setMathMarksAndCH(float, int);
	void setPstMarksAndCH(float, int);
	void setPhyMarksAndCH(float, int);

	//Accessor
	float getPercentage();
	float calculateGPA(float);
	float getEngGPA();
	float getUrduGPA();
	float getMathGPA();
	float getIslGPA();
	float getPstGPA();
	float getPhyGPA();
	float getCGPA();
};