#include<iostream>
#include<string>
#include"GPA.h"

using namespace std;

int main() {

	GPA* ptr = nullptr;
	ptr = new GPA;


	cout << endl << "Total Percentage is: " << ptr->getPercentage();
	cout << endl << "The CGPA is: " << ptr->getCGPA() << endl;

	delete ptr;
	ptr = nullptr;


	return 0;
}