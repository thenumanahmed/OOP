#include<iostream>
#include<string>
#include"GPA.h"
//=================Funnction definitions==============
//Constructor
GPA::GPA() {
	cout << "Enter marks in English out of 100: ";
	cin >> eng;
	while (eng > 100 || eng < 0){
	    cout<<"Enter marks between 0 and 100: ";
	    cin >> eng;
	}
	cout << "Enter Credit Hours of English: ";
	cin >> engCreditHour;
	while (engCreditHour <= 0){
	    cout<<"Enter Credit Hours greater than 0: ";
	    cin >> engCreditHour;
	}
	cout << "Enter marks in Urdu out of 100: ";
	cin >> urdu;
	while (urdu > 100 || eng < 0){
	    cout<<"Enter marks between 0 and 100: ";
	    cin >> urdu;
	}
	cout << "Enter Credit Hours of Urdu: ";
	cin >> urduCreditHour;
	while (urduCreditHour <= 0){
	    cout<<"Enter Credit Hours greater than 0: ";
	    cin >> urduCreditHour;
	}
	cout << "Enter marks in Islamiyat out of 100: ";
	cin >> isl;
	while (isl > 100 || eng < 0){
	    cout<<"Enter marks between 0 and 100: ";
	    cin >> isl;
	}
	cout << "Enter Credit Hours of islamiyat: ";
	cin >> islCreditHour;
	while (islCreditHour <= 0){
	    cout<<"Enter Credit Hours greater than 0: ";
	    cin >> islCreditHour;
	}
	cout << "Enter marks in Math out of 100: ";
	cin >> math;
	while (math > 100 || eng < 0){
	    cout<<"Enter marks between 0 and 100: ";
	    cin >> math;
	}
	cout << "Enter Credit Hours of Math: ";
	cin >> mathCreditHour;
	while (mathCreditHour <= 0){
	    cout<<"Enter Credit Hours greater than 0: ";
	    cin >> mathCreditHour;
	}
	cout << "Enter marks in Pak Study out of 100: ";
	cin >> pst;
	while (pst > 100 || eng < 0){
	    cout<<"Enter marks between 0 and 100: ";
	    cin >> pst;
	}
	cout << "Enter Credit Hours of Pak Study: ";
	cin >> pstCreditHour;
	while (pstCreditHour <= 0){
	    cout<<"Enter Credit Hours greater than 0: ";
	    cin >> pstCreditHour;
	}
	cout << "Enter marks in Physics out of 100: ";
	cin >> phy;
	while (phy > 100 || eng < 0){
	    cout<<"Enter marks between 0 and 100: ";
	    cin >> phy;
	}
	cout << "Enter Credit Hours of Physics: ";
	cin >> phyCreditHour;
	while (phyCreditHour <= 0){
	    cout<<"Enter Credit Hours greater than 0: ";
	    cin >> phyCreditHour;
	}
}
//Mutators
void GPA::setEngMarksAndCH(float a, int b) {
	eng = a;
	engCreditHour = b;
}
void GPA::setUrduMarksAndCH(float a, int b) {
	urdu = a;
	urduCreditHour = b;
}
void GPA::setIslMarksAndCH(float a, int b) {
	isl = a;
	islCreditHour = b;
}
void GPA::setMathMarksAndCH(float a, int b) {
	math = a;
	mathCreditHour = b;
}
void GPA::setPstMarksAndCH(float a, int b) {
	pst = a;
	pstCreditHour = b;
}
void GPA::setPhyMarksAndCH(float a, int b) {
	phy = a;
	phyCreditHour = b;
}
//Accessors
float GPA::getPercentage() {
	return ((eng + urdu + isl + math + pst + phy) / 6.0);
}
float GPA::getEngGPA(){
	return calculateGPA(eng);
}
float GPA::getUrduGPA(){
	return calculateGPA(urdu);
}
float GPA::getMathGPA(){
	return calculateGPA(math);
}
float GPA::getIslGPA(){
	return calculateGPA(isl);
}
float GPA::getPstGPA(){
	return calculateGPA(pst);
}
float GPA::getPhyGPA(){
	return calculateGPA(phy);
}

float GPA::calculateGPA(float a) {           //This function will return the gpa of partcular subject

	if (a >= 90) {						     //Marks out of 100 are actually the precentage
		return 4.0;
	}
	else if (a >= 80) {
		return 3.7;
	}
	else if (a >= 70) {
		return 3.3;
	}
	else if (a >= 60) {
		return 3.0;
	}
	else if (a >= 50) {
		return 2.7;
	}
	else if (a >= 40) {
		return 2.3;
	}
	else {
		return 2.0;
	}
}
float GPA::getCGPA() {
	float totalGPA = 0.0,
		totalCreditHour = 0.0;

	totalGPA += (calculateGPA(eng) * engCreditHour);
	totalCreditHour += engCreditHour;
	totalGPA += (calculateGPA(urdu) * urduCreditHour);
	totalCreditHour += urduCreditHour;
	totalGPA += (calculateGPA(math) * mathCreditHour);
	totalCreditHour += mathCreditHour;
	totalGPA += (calculateGPA(isl) * islCreditHour);
	totalCreditHour += islCreditHour;
	totalGPA += (calculateGPA(pst) * pstCreditHour);
	totalCreditHour += pstCreditHour;
	totalGPA += (calculateGPA(phy) * phyCreditHour);
	totalCreditHour += phyCreditHour;

	return totalGPA / totalCreditHour;
}